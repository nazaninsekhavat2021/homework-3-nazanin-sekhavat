def read_data():
    file = open("dataset.txt", "r")
    lines = file.read().split("\n")
    lines = [line for line in lines if len(line) > 0]
    return lines

def form_data(data):
    formatted_data = {}
    i = 0
    
    while i < len(data):
        formatted_data[data[i][1:]] = ""
        j = i
        
        while j + 1 < len(data) and data[j + 1][0] != ">":
            j = j + 1
            formatted_data[data[i][1:]] += data[j]
            
        i = j + 1

    return formatted_data

def find_answer(data):
    name = ""
    gc = 0
    
    for key in data:
        if name == "" or (data[key].count('C') + data[key].count('G')) / len(data[key]) > gc:
            name = key
            gc = (data[key].count('C') + data[key].count('G')) / len(data[key])
    
    return name, gc


data = read_data()
formated_data = form_data(data)      
name, gc = find_answer(formated_data)

print(name)
print(gc)
