s = input()
sc = ""

for ch in s[::-1]:
    if ch == "A":
        sc += "T"
    elif ch == "T":
        sc += "A"
    elif ch == "C":
        sc += "G"
    else:
        sc += "C"
        
print(sc)