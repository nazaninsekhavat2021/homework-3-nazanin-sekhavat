def read_data():
    f = open("dataset.txt", "r")
    data = f.read()
    data = [s for s in data.split('\n') if len(s) > 0]
    return data

def form_data(data):
    new_data = []
    i = 0
    
    while i < len(data):
        j = i + 1
        string = ""
        while j < len(data) and data[j][0] != ">":
            string += data[j]
            j = j + 1
        
        new_data.append(string)
        i = j
        
    return new_data
        
def create_matrix(data):
    matrix = [[0 for j in range(len(data[0]))] for i in range(4)] 
    for i in range(len(data)):
        for j in range(len(data[i])):
            if data[i][j] == "A":
                matrix[0][j] += 1
            elif data[i][j] == "C":
                matrix[1][j] += 1
            elif data[i][j] == "G":
                matrix[2][j] += 1
            else:
                matrix[3][j] += 1
                
    return matrix

def find_answer(matrix):
    string = ""
    
    for i in range(len(matrix[0])):
        index = 0
        char = 'A'
        
        if matrix[1][i] > matrix[index][i]:
            index = 1
            char = 'C'
            
        if matrix[2][i] > matrix[index][i]:
            index = 2
            char = 'G'
            
        if matrix[3][i] > matrix[index][i]:
            index = 3
            char = 'T'

        string += char

    return string

data = read_data()
formated_data = form_data(data)
matrix = create_matrix(formated_data)
result = find_answer(matrix)
            
print(result)
print("A:", *matrix[0])
print("C:", *matrix[1])
print("G:", *matrix[2])
print("T:", *matrix[3])
        
