t = input()
u = ""

for ch in t:
    if ch == 'T':
        u += 'U'
    else:
        u += ch
        
print(u)