s = input()
t = input()
a = []

i = 0
while i < len(s):
    if i + len(t) <= len(s):
        if s[i:i+len(t)] == t:
            a.append(i+1)
    else:
        break
    
    i = i + 1
    
print(" ".join([str(i) for i in a]))