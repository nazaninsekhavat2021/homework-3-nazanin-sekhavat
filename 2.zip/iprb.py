def fact(n):
    f = 1
    i = 2
    
    while i <= n:
        f = f * i
        i = i + 1
        
    return f

def solve(k, m, n):
    all = 4 * (fact(k + m + n) / (fact(2) * fact(k + m + n - 2)))
    aa_aa = 4 * (fact(n) / (fact(2) * fact(n - 2)))
    Aa_aa = 2 * (fact(n) / fact(n - 1) * fact(m) / fact(m - 1))
    Aa_Aa = fact(m) / (fact(2) * fact(m - 2)) 
    answer = (all - (Aa_Aa + Aa_aa + aa_aa)) / all
    return answer

kmn = input().split()
k = int(kmn[0])
m = int(kmn[1])
n = int(kmn[2])

print(solve(k, m, n))