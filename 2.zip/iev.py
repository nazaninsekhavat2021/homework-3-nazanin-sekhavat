l = input().split()
c = 0

for i in range(len(l)):
    if i < 3:
        c += int(l[i]) * 2
    elif i == 3:
        c += int(l[i]) * 1.5
    elif i == 4:
        c += int(l[i]) * 1
    
print(c)